public class TwoDyArray{

int array[][];

	public TwoDyArray(){
		array=new int[m][n];
	}

	public static void main(String args[]){
		 Scanner sc=new Scanner(System.in);  
		System.out.println("Enter number of Column:");
		int n=sc.nextInt();

		System.out.println("Enter number of Row:");
		int m=sc.nextInt();

		TwoDyArray twoDyArray=new TwoDyArray();

	}

	public void takeArrayInput(){
		Scanner sc=new Scanner(System.in);  
		for(int row=0;row<m;row++){
			for(int col=0;col<n;col++){
				System.out.println("Array["+row+"] ["+col+"]");
				array[row][col]=sc.nextInt();
			}
		}
	}

	public void printArray(){
		
	}
}
