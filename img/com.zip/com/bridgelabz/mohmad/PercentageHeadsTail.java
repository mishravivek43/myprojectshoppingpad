import java.io.*;
import java.util.Random;

public class PercentageHeadsTail{

	public static void main(String args[]){
		int number=0;
		
		 BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		 PercentageHeadsTail percentageHeadsTail=new PercentageHeadsTail();
		 
			try{
				try{
					do{
						System.out.println("Enter number of times to Flip Coin:");
						number=Integer.parseInt(bufferedReader.readLine());
					}while(!percentageHeadsTail.ValidatePositiveNumber(number));
				}
				catch(NumberFormatException exception){
					System.out.println(exception.getMessage());	
				}
			}catch(IOException exception){
				System.out.println(exception.getMessage());
			}
		
		int tail = percentageHeadsTail.numberOfTail(number);
		double percentageTial = percentageHeadsTail.percentageOfTail(tail,number);

		System.out.println("Percentage of time tial :"+percentageTial);
		System.out.println("Percentage of time Head :"+(100-percentageTial));
	}

	//Calculate the number of Tail
	public int numberOfTail(int number){
		int tail=0;
		Random random=new Random();
		for(int i=0;i<number;i++){
			if(random.nextInt()<0.5)
				tail++;
		}
		return tail;
	}

	//Calculate the percentage of Tail
	public double percentageOfTail(int tail,int number){
		return (100*tail)/number;
		
	}

	//Method to validate Number is Positive
	public boolean ValidatePositiveNumber(int number){
		if(number>0)
			return true;
		else
			return false;
	}

}
