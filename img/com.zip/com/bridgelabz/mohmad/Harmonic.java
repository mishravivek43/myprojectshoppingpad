import java.io.*;

public class Harmonic{
	
	public static void main(String args[]){
		int number;
		Harmonic harmonic=new Harmonic();

		do{
			System.out.println("Enter Number (N):");
			number=harmonic.inputInteger();
		}while(!harmonic.checkNumberIsZero(number));
		System.out.println("Harmonic :"+harmonic.calculateHarmonic(number));
		
	}

	//Take Integer Input
	public int inputInteger(){
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		 
			try{
				try{
						
					return Integer.parseInt(bufferedReader.readLine());
				}
				catch(NumberFormatException exception){
					System.out.println(exception.getMessage());	
				}
			}catch(IOException exception){
				System.out.println(exception.getMessage());
			}
		return 0;
	}

	// check Number Is Zero
	public boolean checkNumberIsZero(int number){
		if(number==0)
			return false;
		else
			return true;
	}

	public double calculateHarmonic(int number){
		double result=0;
		for(int i=1;i<=number;i++){
			
			result=result+(1.0/i);
			System.out.println(result);
		}
		return result;
	}

	
}
