
import java.io.*;
public class UserNameReplacer{

public static final String template="Hello UserName, How are you?";

	public static void main(String args[]){
		String UserName=new String();
		 BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

		do{
			System.out.println("Enter The UserName: ");
			try{
				UserName=bufferedReader.readLine();
			}catch(Exception exception){
				System.out.println(exception.getMessage());
			}
		}while(checkLengthOfUserName(UserName));

		System.out.println("Input is correct");

		stringReplacer(UserName);		
		
	}

	//Checking lenth of the User Name
	public static boolean checkLengthOfUserName(String UserName){
		if(UserName.length()<3){
			System.out.println("UserName lenght should grater then 3");
			return true;
		}
		else{
			return false;
		}
	}
	
	//Replace the template by UserName
	public static void stringReplacer(String userName){
		System.out.println(template.replaceAll("UserName",userName));
	}
}
