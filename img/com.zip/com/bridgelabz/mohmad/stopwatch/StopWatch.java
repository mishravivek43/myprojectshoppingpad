import java.io.*;

public class StopWatch{

	BufferedReader bufferedReader;
	public StopWatch(){
		bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	}

	//Take choice input
	public String inputChoice(){
		 
			try{
				return bufferedReader.readLine();
			}catch(IOException exception){
				System.out.println(exception.getMessage());
			}
		return "";
	}
	
	public static void main(String args[]){
		String finish=new String();
		boolean started=true;
		StopWatch stopWatch=new StopWatch();
		long time=0;
		long lastStart=System.currentTimeMillis();
		do{

				if(started){
					System.out.println("press N to stop");
					finish=stopWatch.inputChoice();
					if(finish.equals("N")){
						time=System.currentTimeMillis()-lastStart;
						System.out.println("Time is:"+(time%1000)+" Second");
						started=false;
					}
				}
				else{
					System.out.println("press Y to start");
					finish=stopWatch.inputChoice();
					if(finish.equals("Y")){
						lastStart=System.currentTimeMillis();
						started=true;
					}
					
				}
				System.out.println("Press C to continue");
				finish=stopWatch.inputChoice();
			
		}while(true);
	}
}
