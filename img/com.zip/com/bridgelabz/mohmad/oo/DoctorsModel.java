public class DoctorsModel{
	private String name,specialization,availability;
	private int id;
	Utility utility;
	public DoctorsModel(){
		utility=new Utility();
		System.out.println("Enter Doctors Details ...");

		System.out.print("Enter Name: ");
		this.name=utility.inputWord();
		System.out.println();
	}
}
