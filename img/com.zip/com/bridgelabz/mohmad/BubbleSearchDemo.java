import java.util.Arrays;

public class BubbleSearchDemo{
	public static void main(String args[]){
		Utility utility=new Utility();
		System.out.println("Enter Array Size");
		int arraySize=utility.inputInteger();
		int array[]=utility.input1DArray(arraySize);
		print2DArray
		
	}
}

