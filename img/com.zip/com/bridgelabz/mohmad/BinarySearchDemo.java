import java.util.Arrays;

public class BinarySearchDemo{
	public static void main(String args[]){
		Utility utility=new Utility();
		System.out.println("Enter Array Size");
		int arraySize=utility.inputInteger();
		String array[]=utility.input1DStringArray(arraySize);
		Arrays.sort(array);
		utility.print1DStringArray(array);
		System.out.println("Enter Key");
		int position=utility.binarySearchString(array,utility.inputWord());
		if(position==-1)
			System.out.println("Not Found");
		else
			System.out.println("Found at "+position);
	}
}

