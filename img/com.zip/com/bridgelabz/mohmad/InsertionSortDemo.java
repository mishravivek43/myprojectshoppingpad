public class InsertionSortDemo{

	public static void main(String args[]){
		Utility utility=new Utility();
		System.out.println("Enter Statement:");
		String statement=utility.inputWord();
		String words[]=utility.wordsArrayFromStatement(statement);
		words=utility.insertationSort4String(words);
		utility.print1DStringArray(words);
	}
}

