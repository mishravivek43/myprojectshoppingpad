import java.io.*;

public class Problem10{

	public static void main(String args[]){
		Utility utility=new Utility();

		System.out.println("Enter Size of Array (N):");
		int arraySize=utility.inputInteger();
		int array[]=utility.input1DArray(arraySize);
		utility.print2DArray(array);
		//findDistinctTriples(array);

	}

	public static int findDistinctTriples(int array[]){
		int n=0;
		for(int i=0;i<array.length-3;i++){
			for(int j=i+1;i<array.length-2;j++){
				for(int k=j+1;k<array.length-1;k++){
					if(array[i]+array[j]+array[k]==0){
						System.out.println(i+" "+j+" "+k+" = "+"0");
						n++;
					}
				}
			}
		}
		return n;

	}

	
}
